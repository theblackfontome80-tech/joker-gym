/* ==========================================================================
   THE JOKER GYM — scripts
   ========================================================================== */

/* ---- CONFIGURATION : à compléter lorsque les informations sont confirmées ---- */
const CONFIG = {
  phone: '+21658822239',
  // Numéro WhatsApp officiel, format international sans + ni espaces (ex. '21658822239').
  // Laisser vide tant qu'il n'est pas confirmé : le bouton WhatsApp reste masqué.
  whatsapp: '',
  // URL d'un service de formulaire (Formspree, Getform, backend maison…).
  // Vide : le formulaire prépare un SMS (mobile) ou propose de copier le message.
  formEndpoint: '',
  timezone: 'Africa/Tunis',
  // Horaires (vérifiés sur la fiche Google). 0 = dimanche … 6 = samedi.
  hours: {
    0: ['09:00', '17:00'], 1: ['06:00', '22:00'], 2: ['06:00', '22:00'], 3: ['06:00', '22:00'],
    4: ['06:00', '22:00'], 5: ['06:00', '22:00'], 6: ['09:00', '17:00'],
  },
};

document.documentElement.classList.remove('no-js');

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

/* ---------------------------------------------------- heure locale Bizerte */
function tunisNow() {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: CONFIG.timezone, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
  }).formatToParts(new Date());
  const get = (t) => parts.find((p) => p.type === t).value;
  const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(get('weekday'));
  return { day, minutes: (+get('hour') % 24) * 60 + +get('minute') };
}
const toMin = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
const dayNames = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];

function updateStatus() {
  const { day, minutes } = tunisNow();
  const [o, c] = CONFIG.hours[day];
  const open = minutes >= toMin(o) && minutes < toMin(c);
  let text;
  if (open) {
    text = `Ouvert · ferme à ${c.replace(':', 'h')}`;
  } else if (minutes < toMin(o)) {
    text = `Fermé · ouvre à ${o.replace(':', 'h')}`;
  } else {
    const next = (day + 1) % 7;
    text = `Fermé · ouvre ${dayNames[next]} ${CONFIG.hours[next][0].replace(':', 'h')}`;
  }
  $$('[data-status-text]').forEach((el) => (el.textContent = text));
  $$('[data-status-dot]').forEach((el) => {
    el.classList.toggle('is-open', open);
    el.classList.toggle('is-closed', !open);
  });
  $$(`[data-day="${day}"]`).forEach((el) => el.classList.add('is-today'));
}
updateStatus();
setInterval(updateStatus, 60_000);

/* ------------------------------------------------------------- navigation */
const nav = $('#nav');
const burger = $('.nav__burger');
const menu = $('#menu');
let lastY = window.scrollY;

function onScroll() {
  const y = window.scrollY;
  nav.classList.toggle('is-solid', y > 40);
  const menuOpen = burger.getAttribute('aria-expanded') === 'true';
  nav.classList.toggle('is-hidden', !menuOpen && y > 600 && y > lastY);
  lastY = y;
}
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

function setMenu(open) {
  burger.setAttribute('aria-expanded', String(open));
  burger.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
  menu.hidden = !open;
  document.body.style.overflow = open ? 'hidden' : '';
  nav.classList.toggle('is-solid', open || window.scrollY > 40);
}
burger.addEventListener('click', () => setMenu(burger.getAttribute('aria-expanded') !== 'true'));
$$('a', menu).forEach((a) => a.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !menu.hidden) setMenu(false); });

// lien actif selon la section visible
const sectionLinks = $$('.nav__links a');
const spy = new IntersectionObserver((entries) => {
  entries.forEach((en) => {
    if (!en.isIntersecting) return;
    sectionLinks.forEach((a) => a.classList.toggle('is-current', a.hash === `#${en.target.id}`));
  });
}, { rootMargin: '-45% 0px -50% 0px' });
$$('main section[id]').forEach((s) => spy.observe(s));

/* --------------------------------------------------- apparitions au scroll */
const io = new IntersectionObserver((entries) => {
  entries.forEach((en) => {
    if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
$$('.reveal').forEach((el, i) => {
  // léger décalage entre éléments frères
  const sibs = [...el.parentElement.children].filter((c) => c.classList.contains('reveal'));
  el.style.transitionDelay = `${Math.min(sibs.indexOf(el), 5) * 70}ms`;
  io.observe(el);
});

/* ------------------------------------------------------------ disciplines */
const rows = $$('.d-row');
const stage = $('[data-stage]');
function activate(row) {
  if (row.classList.contains('is-active')) return;
  rows.forEach((r) => {
    r.classList.toggle('is-active', r === row);
    $('.d-row__btn', r).setAttribute('aria-expanded', String(r === row));
  });
  if (stage && getComputedStyle(stage.parentElement).display !== 'none') {
    stage.classList.add('is-swapping');
    const img = new Image();
    img.src = row.dataset.img;
    img.decode().catch(() => {}).finally(() => {
      stage.src = row.dataset.img;
      stage.classList.remove('is-swapping');
    });
  }
}
rows.forEach((row) => {
  const btn = $('.d-row__btn', row);
  btn.setAttribute('aria-expanded', String(row.classList.contains('is-active')));
  btn.addEventListener('click', () => activate(row));
  if (window.matchMedia('(hover: hover)').matches) {
    btn.addEventListener('mouseenter', () => activate(row));
  }
});

/* --------------------------------------------------------------- lightbox */
const lb = $('#lightbox');
const lbImg = $('img', lb);
const tiles = $$('.tile');
let current = 0;
function show(i) {
  current = (i + tiles.length) % tiles.length;
  const t = tiles[current];
  lbImg.src = t.dataset.full;
  lbImg.alt = $('img', t).alt;
}
tiles.forEach((t, i) => t.addEventListener('click', () => { show(i); lb.showModal(); }));
$('.lightbox__close').addEventListener('click', () => lb.close());
$('.lightbox__prev').addEventListener('click', () => show(current - 1));
$('.lightbox__next').addEventListener('click', () => show(current + 1));
lb.addEventListener('click', (e) => { if (e.target === lb) lb.close(); });
lb.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') show(current - 1);
  if (e.key === 'ArrowRight') show(current + 1);
});

/* --------------------------------------------------------------- WhatsApp */
if (CONFIG.whatsapp) {
  $$('[data-whatsapp]').forEach((a) => {
    a.href = `https://wa.me/${CONFIG.whatsapp}`;
    a.hidden = false;
  });
}

/* ------------------------------------------------------------ formulaire */
const form = $('#contact-form');
const status = $('.form__status', form);
const subject = $('#subject');

// « Demander nos tarifs » pré-remplit l'objet
$$('[data-subject]').forEach((a) => a.addEventListener('click', () => { subject.value = a.dataset.subject; }));

function setStatus(msg, kind) {
  status.textContent = msg;
  status.className = `form__status ${kind ? `is-${kind}` : ''}`;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  let firstInvalid = null;
  $$('input, textarea', form).forEach((f) => {
    const bad = f.required && !f.value.trim();
    f.closest('.field').classList.toggle('has-error', bad);
    if (bad && !firstInvalid) firstInvalid = f;
  });
  if (firstInvalid) {
    setStatus('Merci de remplir votre nom, votre téléphone et votre message.', 'err');
    firstInvalid.focus();
    return;
  }

  const data = Object.fromEntries(new FormData(form));
  const text = `Bonjour The Joker Gym,\n\n${data.message}\n\n— ${data.name} (${data.phone})\nObjet : ${data.subject}`;

  if (CONFIG.formEndpoint) {
    try {
      setStatus('Envoi en cours…');
      const res = await fetch(CONFIG.formEndpoint, {
        method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error(res.status);
      form.reset();
      setStatus('Merci, votre message a bien été envoyé. Nous vous recontactons rapidement.', 'ok');
    } catch {
      setStatus('L\'envoi a échoué. Appelez-nous au 58 822 239.', 'err');
    }
    return;
  }

  if (CONFIG.whatsapp) {
    window.open(`https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
    setStatus('Votre message est prêt dans WhatsApp : il ne reste qu\'à l\'envoyer.', 'ok');
    return;
  }

  const isMobile = window.matchMedia('(pointer: coarse)').matches;
  if (isMobile) {
    window.location.href = `sms:${CONFIG.phone}?&body=${encodeURIComponent(text)}`;
    setStatus('Votre message est prêt dans l\'application SMS : il ne reste qu\'à l\'envoyer.', 'ok');
  } else {
    try { await navigator.clipboard.writeText(text); } catch { /* presse-papiers indisponible */ }
    setStatus('Message copié. Envoyez-le par SMS ou appelez le +216 58 822 239 — ou écrivez-nous sur Instagram.', 'ok');
  }
});

$$('input, textarea', form).forEach((f) => f.addEventListener('input', () => f.closest('.field').classList.remove('has-error')));

/* -------------------------------------------------------------------- an */
$$('[data-year]').forEach((el) => (el.textContent = new Date().getFullYear()));
